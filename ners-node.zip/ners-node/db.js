const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_FILE = path.join(__dirname, 'data', 'db.json');

/**
 * A tiny file-backed data store. Replaces the MySQL database entirely —
 * no XAMPP, no separate database server, nothing to install or configure.
 * All data lives in data/db.json and is loaded into memory on start,
 * then written back to disk after every change.
 */
function load() {
  if (!fs.existsSync(DB_FILE)) {
    const seed = {
      nextUserId: 2,
      nextReportId: 1,
      nextSosId: 1,
      users: [
        {
          id: 1,
          fullname: 'System Admin',
          email: 'admin@ngers.gov.ng',
          phone: '08000000000',
          // bcrypt hash of "admin123" — same demo-account pattern as the finance tracker
          password: bcrypt.hashSync('admin123', 10),
          role: 'admin',
          created_at: new Date().toISOString()
        }
      ],
      reports: [],
      sos_alerts: []
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(seed, null, 2));
    return seed;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

let db = load();

function save() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ---------- Users ----------

function findUserByEmail(email) {
  return db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
}

function findUserById(id) {
  return db.users.find(u => u.id === Number(id));
}

function createUser({ fullname, email, phone, password }) {
  const hashed = bcrypt.hashSync(password, 10);
  const user = {
    id: db.nextUserId++,
    fullname,
    email,
    phone,
    password: hashed,
    role: 'user',
    created_at: new Date().toISOString()
  };
  db.users.push(user);
  save();
  return user;
}

function findAdminPhone() {
  const admin = db.users.find(u => u.role === 'admin');
  return admin ? admin.phone : '08000000000';
}

// ---------- Reports ----------

function createReport({ user_id, type, severity, description, latitude, longitude, address }) {
  const report = {
    id: db.nextReportId++,
    user_id: Number(user_id),
    type,
    severity,
    description,
    latitude: latitude || null,
    longitude: longitude || null,
    address,
    status: 'pending',
    reported_at: new Date().toISOString()
  };
  db.reports.push(report);
  save();
  return report;
}

function getReportsByUser(userId, limit = 8) {
  return db.reports
    .filter(r => r.user_id === Number(userId))
    .sort((a, b) => new Date(b.reported_at) - new Date(a.reported_at))
    .slice(0, limit);
}

function getAllReports(limit = 50) {
  return db.reports
    .map(r => {
      const user = findUserById(r.user_id);
      return { ...r, fullname: user ? user.fullname : 'Unknown', phone: user ? user.phone : '' };
    })
    .sort((a, b) => {
      // pending first, then newest first — mirrors the original SQL ORDER BY
      if ((a.status === 'pending') !== (b.status === 'pending')) {
        return a.status === 'pending' ? -1 : 1;
      }
      return new Date(b.reported_at) - new Date(a.reported_at);
    })
    .slice(0, limit);
}

function reportCounts(userId = null) {
  const scoped = userId ? db.reports.filter(r => r.user_id === Number(userId)) : db.reports;
  return {
    total: scoped.length,
    pending: scoped.filter(r => r.status === 'pending').length,
    dispatched: scoped.filter(r => r.status === 'dispatched').length,
    resolved: scoped.filter(r => r.status === 'resolved').length
  };
}

function updateReportStatus(id, status) {
  const report = db.reports.find(r => r.id === Number(id));
  if (report && ['pending', 'dispatched', 'resolved'].includes(status)) {
    report.status = status;
    save();
  }
}

// ---------- SOS alerts ----------

function createSOS({ user_id, fullname, phone, latitude, longitude, address, message }) {
  const sos = {
    id: db.nextSosId++,
    user_id: Number(user_id),
    fullname,
    phone,
    latitude: latitude || null,
    longitude: longitude || null,
    address: address || 'Location not specified',
    message: message || 'SOS ALERT — Immediate emergency assistance required!',
    status: 'active',
    created_at: new Date().toISOString()
  };
  db.sos_alerts.push(sos);
  save();
  return sos;
}

function getSOSByUser(userId, limit = 5) {
  return db.sos_alerts
    .filter(s => s.user_id === Number(userId))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, limit);
}

function getAllSOS(limit = 50) {
  return [...db.sos_alerts]
    .sort((a, b) => {
      if ((a.status === 'active') !== (b.status === 'active')) {
        return a.status === 'active' ? -1 : 1;
      }
      return new Date(b.created_at) - new Date(a.created_at);
    })
    .slice(0, limit);
}

function sosCounts(userId = null) {
  const scoped = userId ? db.sos_alerts.filter(s => s.user_id === Number(userId)) : db.sos_alerts;
  return {
    total: scoped.length,
    active: scoped.filter(s => s.status === 'active').length
  };
}

function updateSOSStatus(id, status) {
  const sos = db.sos_alerts.find(s => s.id === Number(id));
  if (sos && ['active', 'responded', 'closed'].includes(status)) {
    sos.status = status;
    save();
  }
}

module.exports = {
  findUserByEmail, findUserById, createUser, findAdminPhone,
  createReport, getReportsByUser, getAllReports, reportCounts, updateReportStatus,
  createSOS, getSOSByUser, getAllSOS, sosCounts, updateSOSStatus
};
