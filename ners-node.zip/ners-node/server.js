const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Date formatter used by templates — mirrors PHP's date('d M, H:i', strtotime(...))
app.locals.fmtDate = function (isoString) {
  const d = new Date(isoString);
  const day = String(d.getDate()).padStart(2, '0');
  const month = d.toLocaleString('en-GB', { month: 'short' });
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${day} ${month}, ${hours}:${minutes}`;
};

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'ners-nigeria-student-project-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 8 } // 8 hour session
}));

function requireLogin(req, res, next) {
  if (!req.session.user) return res.redirect('/');
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user) return res.redirect('/');
  if (req.session.user.role !== 'admin') return res.redirect('/dashboard');
  next();
}

// ---------- index.php (login/signup) ----------

app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect(req.session.user.role === 'admin' ? '/admin' : '/dashboard');
  }
  res.render('index', {
    tab: req.query.tab || 'login',
    error: req.query.error || '',
    success: req.query.success || ''
  });
});

// ---------- auth.php ----------

app.post('/auth/signup', (req, res) => {
  const { fullname, email, phone, password, confirm_password } = req.body;

  if (password !== confirm_password) {
    return res.redirect('/?error=' + encodeURIComponent('Passwords do not match') + '&tab=signup');
  }

  if (db.findUserByEmail(email)) {
    return res.redirect('/?error=' + encodeURIComponent('Email already registered') + '&tab=signup');
  }

  db.createUser({ fullname: fullname.trim(), email: email.trim(), phone: phone.trim(), password });
  res.redirect('/?success=' + encodeURIComponent('Account created! Please log in'));
});

app.post('/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.findUserByEmail(email ? email.trim() : '');

  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.redirect('/?error=' + encodeURIComponent('Invalid email or password'));
  }

  req.session.user = { id: user.id, fullname: user.fullname, role: user.role };
  res.redirect(user.role === 'admin' ? '/admin' : '/dashboard');
});

// ---------- logout.php ----------

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/?success=' + encodeURIComponent('You have been logged out'));
  });
});

// ---------- Dashboard.php ----------

app.get('/dashboard', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const user = db.findUserById(userId);
  const counts = db.reportCounts(userId);
  const sos = db.sosCounts(userId);

  res.render('dashboard', {
    fullname: req.session.user.fullname,
    userPhone: user ? user.phone : '',
    adminPhone: db.findAdminPhone(),
    reports: db.getReportsByUser(userId, 8),
    mySOSAlerts: db.getSOSByUser(userId, 5),
    total: counts.total,
    pending: counts.pending,
    dispatched: counts.dispatched,
    resolved: counts.resolved,
    sos_total: sos.total,
    error: req.query.error || '',
    success: req.query.success || ''
  });
});

// ---------- report.php ----------

app.post('/report', requireLogin, (req, res) => {
  const { type, severity, description, latitude, longitude, address } = req.body;

  try {
    const report = db.createReport({
      user_id: req.session.user.id,
      type,
      severity,
      description: (description || '').trim(),
      latitude: latitude || null,
      longitude: longitude || null,
      address: (address || '').trim()
    });
    res.redirect('/dashboard?success=' + encodeURIComponent(`Emergency reported! ID:#${report.id}`));
  } catch (err) {
    res.redirect('/dashboard?error=' + encodeURIComponent('Failed to submit report'));
  }
});

// ---------- sos.php ----------

app.post('/sos', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const user = db.findUserById(userId);

  if (!user) {
    return res.json({ success: false, message: 'User not found' });
  }

  const { latitude, longitude, address, message } = req.body;

  const sos = db.createSOS({
    user_id: userId,
    fullname: user.fullname,
    phone: user.phone,
    latitude: latitude ? Number(latitude) : null,
    longitude: longitude ? Number(longitude) : null,
    address: (address || 'Location not specified').trim(),
    message: (message || 'SOS ALERT — Immediate emergency assistance required!').trim()
  });

  res.json({
    success: true,
    sos_id: sos.id,
    fullname: sos.fullname,
    phone: sos.phone,
    message: `SOS saved. ID #${sos.id}`
  });
});

// ---------- get_user_info.php ----------

app.get('/api/user-info', (req, res) => {
  if (!req.session.user) return res.json({ error: 'Not logged in' });
  const user = db.findUserById(req.session.user.id);
  res.json({ phone: user ? user.phone : '', fullname: user ? user.fullname : '' });
});

// ---------- admin.php ----------

app.get('/admin', requireAdmin, (req, res) => {
  const reportCounts = db.reportCounts();
  const sosCounts = db.sosCounts();

  res.render('admin', {
    fullname: req.session.user.fullname,
    total: reportCounts.total,
    pending: reportCounts.pending,
    dispatched: reportCounts.dispatched,
    resolved: reportCounts.resolved,
    sos_active: sosCounts.active,
    sos_total: sosCounts.total,
    sosAlerts: db.getAllSOS(50),
    reports: db.getAllReports(50),
    error: req.query.error || '',
    success: req.query.success || ''
  });
});

app.post('/admin/update-sos-status', requireAdmin, (req, res) => {
  db.updateSOSStatus(req.body.sos_id, req.body.status);
  res.redirect('/admin?success=' + encodeURIComponent('SOS status updated'));
});

app.post('/admin/update-report-status', requireAdmin, (req, res) => {
  db.updateReportStatus(req.body.report_id, req.body.status);
  res.redirect('/admin?success=' + encodeURIComponent('Report status updated'));
});

app.listen(PORT, () => {
  console.log(`NERS Nigeria running at http://localhost:${PORT}`);
  console.log(`Login as admin: admin@ngers.gov.ng / admin123`);
});
