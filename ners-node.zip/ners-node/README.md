# NERS Nigeria — Node.js version

A full port of your PHP/XAMPP Emergency Response System to Node.js —
**same features, same look, no XAMPP or MySQL required.**

## What changed vs. the PHP version

| | PHP version | This version |
|---|---|---|
| Server | Apache (via XAMPP) | Node.js + Express |
| Database | MySQL (via XAMPP) | A JSON file (`data/db.json`), created automatically |
| Templating | PHP tags mixed into HTML | EJS templates (same HTML/CSS/JS, different tag syntax) |
| Password hashing | PHP's `password_hash()` (bcrypt) | `bcryptjs` (bcrypt, pure JavaScript) |

Nothing about the **features** changed — signup/login, the SOS hold-button
with geolocation, the severity meter, the state/landmark picker, emergency
reports, the admin panel with live SOS/report status updates — all of it
works exactly as before. The CSS is untouched (copied byte-for-byte), so it
looks identical.

## Why no more MySQL?

Your reports/SOS/user data is now stored in `data/db.json`, a plain JSON
file that Node reads into memory on startup and writes back to after every
change. For a project of this size that's simpler and more portable than
running a full MySQL server — nothing to install, nothing to configure,
and no `db.php` connection settings to get wrong. If your course requires
you to demonstrate SQL specifically, let me know and I can swap this for
`mysql2` instead — the rest of the app wouldn't need to change.

## Running it

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

**Default admin account** (seeded automatically on first run):
- Email: `admin@ngers.gov.ng`
- Password: `admin123`

Regular accounts are created via the Sign Up tab, same as before.

## Project structure

```
ners-node/
  server.js          — all routes (equivalent to index.php, auth.php, report.php, sos.php, admin.php, logout.php)
  db.js              — the JSON-file data layer (equivalent to db.php + your SQL schema)
  data/db.json        — created on first run; holds users, reports, sos_alerts
  views/
    index.ejs        — login/signup page (was index.php)
    dashboard.ejs    — user dashboard: SOS button, report form, history (was Dashboard.php)
    admin.ejs        — admin panel: incoming SOS + reports management (was admin.php)
  public/
    style.css        — unchanged from your original
    bg.jpeg          — unchanged from your original
```

## Route map (PHP file → Node route)

| Old PHP file | New route |
|---|---|
| `index.php` | `GET /` |
| `auth.php` (signup) | `POST /auth/signup` |
| `auth.php` (login) | `POST /auth/login` |
| `logout.php` | `GET /logout` |
| `dashboard.php` | `GET /dashboard` |
| `report.php` | `POST /report` |
| `sos.php` | `POST /sos` |
| `get_user_info.php` | `GET /api/user-info` |
| `admin.php` | `GET /admin` |
| `admin.php` (SOS status update) | `POST /admin/update-sos-status` |
| `admin.php` (report status update) | `POST /admin/update-report-status` |

## A note on data persistence

Unlike the finance tracker project, this one **does** persist — `data/db.json`
is written to disk after every signup, report, or SOS alert, so your data
survives server restarts. If you ever want to reset everything, just delete
`data/db.json` and restart the server — it will recreate the file with a
fresh default admin account.
